#' @title MCP
#' @description The proximal operator of MCP
#' @param lambda The tuning parameter for the  penalty
#' @param eta The constant for the proximal operator of the penalty
#' @param bb The constant vector in the proximal operator
#' @return The solution for the proximal operator of MCP
#' @export
MCP<-function(lambda,eta,bb){
  a=3
  beta_k=rep(0, length(bb))
  for (i in 1:length(bb)) {
    if(abs(bb[i])<lambda*a*(eta)/eta){beta_k[i]=sign(bb[i])*
      max((a*eta*abs(bb[i])-
             a*lambda)/(a*(eta)-1),0)}else{
               beta_k[i] = eta*bb[i]/(eta)}
  }
  return(beta_k)
}
